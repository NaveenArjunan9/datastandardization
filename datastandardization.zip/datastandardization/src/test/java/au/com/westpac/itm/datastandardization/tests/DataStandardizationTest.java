package au.com.westpac.itm.datastandardization.tests;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import au.com.westpac.itm.datastandardization.testconfig.TestConfig;
import au.com.westpac.itm.datastandardization.testutilities.JSONAttributeProvider;
import au.com.westpac.itm.datastandardization.testutilities.StandardizationUtility;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Step;
import io.qameta.allure.Story;

@SpringBootTest

public class DataStandardizationTest extends AbstractTestNGSpringContextTests {
	@Autowired
	JSONAttributeProvider dataProvider;
	@Autowired
	StandardizationUtility standardisationUtility;
	@Autowired
	TestConfig testConfig;

	@BeforeTest
	void testStarts() throws ParseException, IOException {
		System.out.println("::: StandardisationTest Starts:::");
	}

	@Epic("DataPipeline")
	@Feature("Standardisation")
	@Story("TC_Sta_Visidlow")
	@Step("visidLow	decimal(19,0)")
	@Severity(SeverityLevel.MINOR)
	@Description("visidLow	attribute should be decimal(19,0)")
	@Test(priority = 1, description = "VISIDLOW	attribute should be decimal(19,0)")
	void visidLowStandardisation() throws ParseException, IOException, InterruptedException, ExecutionException,
			com.sun.el.parser.ParseException, ClassNotFoundException {
		standardisationUtility.visidLowTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Standardisation")
	@Story("TC_Sta_Visidhigh")
	@Step("visidHigh decimal(19,0)")
	@Severity(SeverityLevel.MINOR)
	@Description("visidHigh	attribute should be decimal(19,0)")
	@Test(priority = 2, description = "VISIDHIGH attribute should be decimal(19,0)")
	void visidHighStandardisation() throws ParseException, IOException, InterruptedException, ExecutionException,
			com.sun.el.parser.ParseException, ClassNotFoundException {
		standardisationUtility.visidHighTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Standardisation")
	@Story("TC_Sta_Ip")
	@Step("ip should statisfy IPV4 format")
	@Severity(SeverityLevel.MINOR)
	@Description("ip should statisfy IPV4 format")
	@Test(priority = 3, description = "IP should statisfy IPV4 format")
	void ipStandardisation() throws ParseException, IOException, InterruptedException, ExecutionException,
			com.sun.el.parser.ParseException, ClassNotFoundException {
		standardisationUtility.ipTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Standardisation")
	@Story("TC_Sta_Bot")
	@Step("bot should not contains <>")
	@Severity(SeverityLevel.MINOR)
	@Description("bot should not contains <>")
	@Test(priority = 4, description = "BOT should not contains <>")
	void botStandardisation() throws ParseException, IOException, InterruptedException, ExecutionException,
			com.sun.el.parser.ParseException, ClassNotFoundException {
		standardisationUtility.botTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Standardisation")
	@Story("TC_Sta_SearchEngine")
	@Step("searchEngine should not contains <>")
	@Severity(SeverityLevel.MINOR)
	@Description("searchEngine should not contains <>")
	@Test(priority = 5, description = "SearchEngine should not contains <>")
	void searchEngineStandardisation() throws ParseException, IOException, InterruptedException, ExecutionException,
			com.sun.el.parser.ParseException, ClassNotFoundException {
		standardisationUtility.searchEngineTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Standardisation")
	@Story("TC_Sta_Javaenabled")
	@Step("javaEnabled should be FALSE")
	@Severity(SeverityLevel.MINOR)
	@Description("javaEnabled should be FALSE")
	@Test(priority = 6, description = "JavaEnabled should be FALSE")
	void javaEnabledStandardisation() throws ParseException, IOException, InterruptedException, ExecutionException,
			com.sun.el.parser.ParseException, ClassNotFoundException {
		standardisationUtility.javaEnabledTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Standardisation")
	@Story("TC_Sta_Value")
	@Step("value should be FALSE")
	@Severity(SeverityLevel.MINOR)
	@Description("value should be FALSE")
	@Test(priority = 7, description = "Value should be FALSE")
	void valueStandardisation() throws ParseException, IOException, InterruptedException, ExecutionException,
			com.sun.el.parser.ParseException, ClassNotFoundException {
		standardisationUtility.valueTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Standardisation")
	@Story("TC_Sta_TimeGMT")
	@Step("timeGMT should be in yyyy-MM-dd HH:mm:ss")
	@Severity(SeverityLevel.MINOR)
	@Description("timeGMT should be in yyyy-MM-dd HH:mm:ss")
	@Test(priority = 8, description = "TimeGMT should be in yyyy-MM-dd HH:mm:ss")
	void timeGMTStandardisation() throws ParseException, IOException, InterruptedException, ExecutionException,
			com.sun.el.parser.ParseException, ClassNotFoundException {
		standardisationUtility.timeGMTTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Standardisation")
	@Story("TC_Sta_ReceivedTimeGMT")
	@Step("receivedTimeGMT should be in yyyy-MM-dd HH:mm:ss")
	@Severity(SeverityLevel.MINOR)
	@Description("receivedTimeGMT should be in yyyy-MM-dd HH:mm:ss")
	@Test(priority = 9, description = "ReceivedTimeGMT should be in yyyy-MM-dd HH:mm:ss")
	void receivedTimeGMTStandardisation() throws ParseException, IOException, InterruptedException, ExecutionException,
			com.sun.el.parser.ParseException, ClassNotFoundException {
		standardisationUtility.receivedTimeGMTTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@AfterTest
	void testEnds() throws ParseException, IOException {
		System.out.println("::: StandardisationTest Ends:::");
	}
}