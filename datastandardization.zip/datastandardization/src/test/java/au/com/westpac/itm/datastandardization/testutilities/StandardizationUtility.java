package au.com.westpac.itm.datastandardization.testutilities;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sun.el.parser.ParseException;

@Component
public class StandardizationUtility {
	@Autowired
	JSONAttributeProvider dataProvider;

	// visidLow Attribute Logic

	public boolean visidLowTestExecutor() throws ParseException, IOException, InterruptedException, ExecutionException,
			org.json.simple.parser.ParseException, ClassNotFoundException {

		dataProvider.initializer();
		String visIdLowValue = dataProvider.attribute_provider("visIdLow");
		int wholeNumberLength = visIdLowValue.split("\\.")[0].length();
		if (wholeNumberLength <= 19) {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;

	}
	// visidHigh Attribute Logic

	public boolean visidHighTestExecutor() throws ParseException, IOException, InterruptedException, ExecutionException,
			org.json.simple.parser.ParseException, ClassNotFoundException {

		dataProvider.initializer();
		String visIdHighValue = dataProvider.attribute_provider("visIdHigh");
		int wholeNumberLength = visIdHighValue.split("\\.")[0].length();
		if (wholeNumberLength <= 19) {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}
		return dataProvider.actualResult;

	}
	// ip Attribute Logic

	public boolean ipTestExecutor() throws ParseException, IOException, InterruptedException, ExecutionException,
			org.json.simple.parser.ParseException, ClassNotFoundException {

		dataProvider.initializer();
		String ip4Regex = "^(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})){3}$";
		Pattern pattern = Pattern.compile(ip4Regex);
		Matcher matcher = pattern.matcher(dataProvider.attribute_provider("ip"));
		if (matcher.find())
			dataProvider.actualResult = true;
		else
			dataProvider.actualResult = false;
		return dataProvider.actualResult;
	}

// bot Attribute Logic
	public boolean botTestExecutor() throws ParseException, org.json.simple.parser.ParseException, IOException,
			InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();
		String botRegex = "^[^<>]*$";
		Pattern pattern = Pattern.compile(botRegex);
		Matcher matcher = pattern.matcher(dataProvider.attribute_provider("bot"));
		if (matcher.find())
			dataProvider.actualResult = true;
		else
			dataProvider.actualResult = false;
		return dataProvider.actualResult;
	}

	// searchEngine Attribute Logic
	public boolean searchEngineTestExecutor() throws ParseException, org.json.simple.parser.ParseException, IOException,
			InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();
		String searchEngineRegex = "^[^<>]*$";
		Pattern pattern = Pattern.compile(searchEngineRegex);
		Matcher matcher = pattern.matcher(dataProvider.attribute_provider("searchEngine"));
		if (matcher.find())
			dataProvider.actualResult = true;
		else
			dataProvider.actualResult = false;
		return dataProvider.actualResult;
	}

	// javaEnabled Attribute Logic

	public boolean javaEnabledTestExecutor() throws ParseException, IOException, InterruptedException,
			ExecutionException, org.json.simple.parser.ParseException, ClassNotFoundException {

		dataProvider.initializer();
		boolean javaEnabledValue = Boolean.parseBoolean(dataProvider.attribute_provider6("javaEnabled"));

		if (!javaEnabledValue) {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}
		return dataProvider.actualResult;

	}
	// value Attribute Logic

	public boolean valueTestExecutor() throws ParseException, IOException, InterruptedException, ExecutionException,
			org.json.simple.parser.ParseException, ClassNotFoundException {

		dataProvider.initializer();
		boolean value = Boolean.parseBoolean(dataProvider.attribute_provider4("value"));

		if (!value) {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}
		return dataProvider.actualResult;

	}

	// timeGMT Attribute Logic

	public boolean timeGMTTestExecutor() throws ParseException, IOException, InterruptedException, ExecutionException,
			org.json.simple.parser.ParseException, ClassNotFoundException {

		dataProvider.initializer();
		Pattern pattern = Pattern
				.compile("^([0-9]{4})-([0-1][0-9])-([0-3][0-9])\\s([0-1][0-9]|[2][0-3]):([0-5][0-9]):([0-5][0-9])$");
		Matcher matcher = pattern.matcher(dataProvider.attribute_provider3("timeGMT"));
		if (matcher.find())
			dataProvider.actualResult = true;
		else
			dataProvider.actualResult = false;
		return dataProvider.actualResult;
	}
	// receivedTimeGMT Attribute Logic

	public boolean receivedTimeGMTTestExecutor() throws ParseException, IOException, InterruptedException,
			ExecutionException, org.json.simple.parser.ParseException, ClassNotFoundException {

		dataProvider.initializer();
		Pattern pattern = Pattern
				.compile("^([0-9]{4})-([0-1][0-9])-([0-3][0-9])\\s([0-1][0-9]|[2][0-3]):([0-5][0-9]):([0-5][0-9])$");
		Matcher matcher = pattern.matcher(dataProvider.attribute_provider3("receivedTimeGMT"));
		if (matcher.find())
			dataProvider.actualResult = true;
		else
			dataProvider.actualResult = false;
		return dataProvider.actualResult;
	}

}