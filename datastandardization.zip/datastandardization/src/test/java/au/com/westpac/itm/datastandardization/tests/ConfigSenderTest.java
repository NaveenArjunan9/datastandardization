package au.com.westpac.itm.datastandardization.tests;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.Test;

import au.com.westpac.itm.datastandardization.producer.ConfigSender;

@SpringBootTest

public class ConfigSenderTest extends AbstractTestNGSpringContextTests {
	@Autowired
	ConfigSender configSender;

	@Test
	void testConfigSender() throws IOException, InterruptedException, ExecutionException {
		configSender.configLogic();
	}

}
