package au.com.westpac.itm.datastandardization.consumer;

import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;

@Configuration
@EnableKafka
public class ReceiverConfig {
}
