package au.com.westpac.itm.datastandardization.producer;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import tech.allegro.schema.json2avro.converter.JsonAvroConverter;

@Component
public class ConfigSender {

	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigSender.class);

	@Autowired
	private KafkaTemplate<byte[], byte[]> kafkaTemplate;

	public void configLogic() throws IOException, InterruptedException, ExecutionException {
		File jsonFile = ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX + "QualifiedEventConfig.json");
		File schemafile = ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX + "StandardizationConfig.avsc");

		String jsonObj = new String(Files.readAllBytes(jsonFile.toPath()), StandardCharsets.UTF_8);
		String schemaObj = new String(Files.readAllBytes(schemafile.toPath()), StandardCharsets.UTF_8);

		JsonAvroConverter converter = new JsonAvroConverter();

		System.out.println("jsonObj" + jsonObj);
		System.out.println("schemaObj" + schemaObj);
		// conversion tobinary Avro
		byte[] binaryAvroConfig = converter.convertToAvro(jsonObj.getBytes(), schemaObj);
		System.out.println(":::avro:::" + new String(binaryAvroConfig));
		// conversion from binary Avro to JSON
		byte[] binaryJson = converter.convertToJson(binaryAvroConfig, schemaObj);
		System.out.println(":::binaryJson:::" + new String(binaryJson));

		kafkaTemplate.send("ev-app-a00ad3-dpstandardizationconfigingress-1", binaryAvroConfig).get();

	}

}
