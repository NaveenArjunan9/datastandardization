package au.com.westpac.itm.datastandardization.consumer;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import tech.allegro.schema.json2avro.converter.JsonAvroConverter;

@Component
public class Receiver {

	private static final Logger LOGGER = LoggerFactory.getLogger(Receiver.class);
	HashMap<Integer, ConsumerRecord<byte[], byte[]>> map = new HashMap<Integer, ConsumerRecord<byte[], byte[]>>();

	@KafkaListener(topics = "ev-app-a00ad3-dpstandardizationegress-1")
	public void onMessage(ConsumerRecord<byte[], byte[]> consumerRecord) {
		System.out.println(":::onMessage Starts:::" + consumerRecord);
		map.put(1, consumerRecord);
	}

	public String consumerLogic() throws ClassNotFoundException, IOException, ParseException {

		System.out.println(":::Receiver Starts:::");
		ConsumerRecord<byte[], byte[]> consumerRecord = map.get(1);

		File schemafile = ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX + "QualifiedEvent.avsc");
		String schemaObj = new String(Files.readAllBytes(schemafile.toPath()));
		JsonAvroConverter converter = new JsonAvroConverter();
		// conversion from binary Avro to JSON
		byte[] binaryJson = converter.convertToJson(consumerRecord.value(), schemaObj);
		String topicValue = new String(binaryJson);

		JSONParser parser = new JSONParser();
		JSONObject json1 = (JSONObject) parser.parse(topicValue);
		JSONObject json2 = (JSONObject) json1.get("signalPayload");
		String jsonMessage = new String(json2.toString());
		jsonMessage = jsonMessage.replace("\\", "");

		String[] firstSplit = jsonMessage.split(":\"", 2);
		String secondSplit = firstSplit[1];

		String[] thirdSplit = secondSplit.split("}\"}", 2);
		String completeString = thirdSplit[0];
		topicValue = completeString + "}";
		System.out.println(":::jsonMessage:::" + topicValue);
		return topicValue;
	}

}