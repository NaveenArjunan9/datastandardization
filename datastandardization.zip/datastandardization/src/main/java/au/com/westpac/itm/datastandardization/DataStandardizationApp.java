package au.com.westpac.itm.datastandardization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class DataStandardizationApp {

	public static void main(String[] args) {
		SpringApplication.run(DataStandardizationApp.class, args);
	}

}
